#ifndef __lib_h__
#define __lib_h__

void printf(const char *format,...);
void sleep(unsigned int time);
int fork();
int exit();
#endif
